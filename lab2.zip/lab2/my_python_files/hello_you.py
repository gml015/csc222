name = input("What's your name? ")
age = input("How old are you? ")
age = int(age) / 2
print(f"Hey {name}, half of your age is {age}")
